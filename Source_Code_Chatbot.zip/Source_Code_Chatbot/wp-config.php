<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'id4288985_wp_3768c8c417996456544c5411f0620dce' );

/** MySQL database username */
define( 'DB_USER', 'id4288985_wp_3768c8c417996456544c5411f0620dce' );

/** MySQL database password */
define( 'DB_PASSWORD', '4769ef6aba84e87879ff2ac2817afe27365c6060' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '!RQbA-UUEY{DOqgB4=hc1o]DMJ/?nB]`]&uw6+u((^]Q]%^Q1:U+<J3Q@Ih $mN^' );
define( 'SECURE_AUTH_KEY',  '6^Rb75c*Ri{e3>+82[|hu?Y~ZO(tT,RC]>U&<.1mom;v~STsoE|>JFl6.y*1H.%$' );
define( 'LOGGED_IN_KEY',    'kDE|@`rlnhzEnWDITtW`^)bMlq4&y:x!qQOk]dQf?dg@4HXb#J7eL+F9PIT<>x}w' );
define( 'NONCE_KEY',        'wMxKte%_@&j$/WNm]2TxA?dT0<z71D;sp]41n_hpTPspLzyfmOoBL${@Go]hGDw<' );
define( 'AUTH_SALT',        'W;na?_yCG^4*KK?4,vZ41}RJW8{(xQG`Kv<cZmQtIonZ,n95c2zeI`3b ;iu3X*h' );
define( 'SECURE_AUTH_SALT', '.I/:O.{S{~Xxuz$0)Q)XT9%A?mbTFA8j(.},/:UEw!f^fLS2RG[hAbWM:+ r))-,' );
define( 'LOGGED_IN_SALT',   'uw+zD@_2!9C%#u}!D^<wbB&FE9)18/WEFLYD.nht H%C;dOP2}Es]q]p~}yhwqP+' );
define( 'NONCE_SALT',       '}!@JGD0,4/k?I]$;e=|.t?7+McykjfwHQ*EPGOV3cd.bCn$2D9MLE9 p24t_cRg!' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
